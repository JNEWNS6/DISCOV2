
import re
from typing import List, Dict

CODE_PATTERNS = [
    r"[A-Z0-9]{5,12}",  # broad; will filter later
    r"[A-Z]{3,}-?\d{2,}",  # e.g., SAVE10, TAKE20
]

# Words that often indicate non-codes (filter noise)
NOISE = {"THIS", "HTTPS", "HTTP", "RETURN", "DELIVERY", "DISCOUNT", "PROMO", "VOUCHER"}

def extract_codes(text: str, limit: int = 50) -> List[Dict]:
    found = set()
    for pat in CODE_PATTERNS:
        for m in re.findall(pat, text.upper()):
            if any(x in m for x in ["HTTP", "WWW"]):
                continue
            if m in NOISE:
                continue
            if len(m) < 5 or len(m) > 20:
                continue
            found.add(m)
            if len(found) >= limit:
                break
    return [{"code": c, "source": "regex"} for c in sorted(found)]
