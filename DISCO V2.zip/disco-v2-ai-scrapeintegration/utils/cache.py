
import sqlite3, json, time, os
from typing import Optional

DB_PATH = os.getenv("DISCO_DB_PATH", "disco.db")
TTL_SECONDS = int(os.getenv("DISCO_SCRAPE_TTL_SECONDS", "600"))  # default 10 minutes

def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS ScrapeCache (domain TEXT, url TEXT, key TEXT, codes_json TEXT, ts INTEGER, PRIMARY KEY(domain, url, key))")
    return conn

def cache_key(domain: str, url: str, html_flag: bool, limit: int) -> str:
    return f"{domain}|{url}|{int(html_flag)}|{limit}"

def get(domain: str, url: str, key: str) -> Optional[list]:
    conn = _conn()
    try:
        cur = conn.execute("SELECT codes_json, ts FROM ScrapeCache WHERE domain=? AND url=? AND key=?", (domain, url or "", key))
        row = cur.fetchone()
        if not row:
            return None
        codes_json, ts = row
        if time.time() - ts > TTL_SECONDS:
            # expired
            conn.execute("DELETE FROM ScrapeCache WHERE domain=? AND url=? AND key=?", (domain, url or "", key))
            conn.commit()
            return None
        return json.loads(codes_json)
    finally:
        conn.close()

def set(domain: str, url: str, key: str, codes: list):
    conn = _conn()
    try:
        conn.execute("INSERT OR REPLACE INTO ScrapeCache(domain, url, key, codes_json, ts) VALUES (?,?,?,?,?)",
                     (domain, url or "", key, json.dumps(codes), int(time.time())))
        conn.commit()
    finally:
        conn.close()
