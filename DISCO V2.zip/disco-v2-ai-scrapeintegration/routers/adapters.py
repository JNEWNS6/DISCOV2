
from fastapi import APIRouter
router = APIRouter()

# Minimal adapter map (extend/replace with real data as needed)
ADAPTERS = {
    "generic": {
        "selectors": [
            "input[name='coupon']",
            "input[name='promo']",
            "input[name='voucher']"
        ],
        "paths": ["/sale", "/offers", "/voucher", "/discount", "/promotions"]
    },
    "retailers_uk": {
        "argos.co.uk": ["/promotions", "/offers"],
        "currys.co.uk": ["/offers", "/discount-codes"],
        "asos.com": ["/sale", "/women/sale", "/men/sale"],
        "boots.com": ["/offers"],
        "tesco.com": ["/offers"],
        "ocado.com": ["/offers"],
        "sainsburys.co.uk": ["/offers"],
        "johnlewis.com": ["/offers", "/sale"],
        "very.co.uk": ["/sale"],
        "next.co.uk": ["/sale"]
    }
}

@router.get("/adapters")
def get_adapters():
    return ADAPTERS
