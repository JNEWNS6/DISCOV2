
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import httpx
from bs4 import BeautifulSoup
from ..utils.parsers import extract_codes
from ..utils import cache as scache
from .adapters import ADAPTERS

router = APIRouter()

class ScrapeReq(BaseModel):
    domain: str
    url: Optional[str] = None
    html: Optional[str] = None
    limit: int = 50

class CodesResp(BaseModel):
    codes: List[Dict]

TIMEOUT = 7.0
MAX_PAGES = 6

def _mk_urls(domain: str, url: Optional[str]) -> List[str]:
    base = f"https://{domain.strip()}"
    paths = ADAPTERS.get("generic", {}).get("paths", [])[:MAX_PAGES]
    # Retailer-specific
    for d, pths in ADAPTERS.get("retailers_uk", {}).items():
        if d == domain:
            paths = (pths + paths)[:MAX_PAGES]
            break
    seen = set()
    out = []
    if url:
        out.append(url)
        seen.add(url)
    for p in paths:
        full = base + p
        if full not in seen:
            out.append(full)
            seen.add(full)
        if len(out) >= MAX_PAGES:
            break
    return out[:MAX_PAGES]

@router.post("/scrape", response_model=CodesResp)
async def scrape(req: ScrapeReq):
    key = scache.cache_key(req.domain, req.url or "", bool(req.html), req.limit)
    cached = scache.get(req.domain, req.url or "", key)
    if cached is not None:
        return {"codes": cached[:req.limit]}

    codes: List[Dict] = []
    try:
        if req.html:
            codes.extend(extract_codes(req.html, limit=req.limit))
        else:
            urls = _mk_urls(req.domain, req.url)
            async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as client:
                for u in urls:
                    try:
                        r = await client.get(u)
                        if r.status_code != 200:
                            continue
                        soup = BeautifulSoup(r.text, "html.parser")
                        text = soup.get_text(" ", strip=True)
                        codes.extend(extract_codes(text, limit=req.limit))
                        if len(codes) >= req.limit:
                            break
                    except Exception:
                        continue
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # Deduplicate by code (case-insensitive)
    dedup = []
    seen = set()
    for c in codes:
        k = c["code"].strip().upper()
        if k not in seen:
            seen.add(k)
            dedup.append({"code": k, "source": c.get("source") or "remote:/scrape"})
        if len(dedup) >= req.limit:
            break

    scache.set(req.domain, req.url or "", key, dedup)
    return {"codes": dedup}
