
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Optional
from .scrape import scrape, ScrapeReq
from .adapters import ADAPTERS

router = APIRouter()

class SuggestReq(BaseModel):
    domain: str
    url: Optional[str] = None
    html: Optional[str] = None
    limit: int = 50

def _dedupe(codes: List[Dict], limit: int) -> List[Dict]:
    out, seen = [], set()
    for c in codes:
        k = c["code"].strip().upper()
        if k in seen: continue
        seen.add(k); out.append({"code": k, "source": c.get("source")})
        if len(out) >= limit: break
    return out

@router.post("/suggest")
async def suggest(req: SuggestReq):
    merged: List[Dict] = []

    # 1) recent-success codes: placeholder (integrate with your /event storage if present)
    # For now, just an empty list to avoid assumptions.
    recent: List[Dict] = []
    merged.extend(recent)

    # 2) live-scraped
    scr = await scrape(ScrapeReq(**req.model_dump()))
    merged.extend([{**c, "source": c.get("source") or "remote:/scrape"} for c in scr["codes"]])

    # 3) seeded (placeholder hook: replace with actual seed store if present)
    seeded: List[Dict] = []

    merged.extend([{**c, "source": c.get("source") or "seed"} for c in seeded])
    return {"codes": _dedupe(merged, req.limit)}
